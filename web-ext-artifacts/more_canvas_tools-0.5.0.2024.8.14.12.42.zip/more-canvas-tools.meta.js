// ==UserScript==
// @name         More Canvas Tools
// @version      0.5.0.2024.8.14.12.42
// @description  Next generation canvas tools for simplifying your life
// @author       Austin Cory Bart
// @match        *://*.instructure.com/*
// @namespace    udcis.canvas
// @run-at       document-start
// @grant        none
// @updateURL    https://ud-cis-teaching.github.io/more-canvas-tools/more-canvas-tools.user.js
// @downloadURL  https://ud-cis-teaching.github.io/more-canvas-tools/more-canvas-tools.user.js
// ==/UserScript==